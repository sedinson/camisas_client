paper-progress
===================

See the [component page](http://www.polymer-project.org/docs/elements/paper-elements.html#paper-progress) for more information.
