core-header-panel
===================

See the [component page](http://polymer.github.io/core-header-panel) for more information.
